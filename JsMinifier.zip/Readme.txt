# This is a small tool that minifies the js/ts files.
## Arguments
- arg[1] = Input js/ts file path
- arg[2] = Output js/ts file path